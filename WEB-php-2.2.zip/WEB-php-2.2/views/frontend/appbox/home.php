
<section id="getForFree" class="pageRow">
    <div class="wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="title_bold text-center ralewaySemiBold wow zoomIn blackTxtColor" data-wow-delay="0.3s"><?=_lang("GET IT FOR FREE")?> </h2>
                <span class="subtitle text-center raleway col-lg-12 col-md-12 col-sm-12 col-xs-12 wow zoomIn" data-wow-delay="0.3s"><?=_lang("Choose your native platform and download the app FREE")?>!</span>
                <div class="clearfix"></div>
                <ul class="store-buttons center-block clearfix arrowGetFree">
                    <li class=" wow fadeInLeft" data-wow-delay="0.3s">
                        <a target="_blank" href="https://drive.google.com/file/d/1ZE4C5SggVKGkr_AlQgJatbBKgpQm4dgw" class="ellipseBtn bigBtn whiteBtn hvr-pop">
									<span>
										<i class="fa-custom-google-play"></i>
										Google Play
									</span>
                        </a>
                    </li>
                    <li class=" wow fadeInRight" data-wow-delay="0.3s">
                        <a target="_blank" href="https://apps.apple.com/us/app/nearbystores/id1422430308?l=en" class="ellipseBtn bigBtn colorBtn hvr-pop">
									<span>
										<i class="fa fa-apple"></i>
										iOS App Store
									</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>
<section id="amazingFeatures" class="pageRow skew skew-top graySection">
    <div class="wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h3 class="sectionTitle text-center ralewayLight balck"><?=_lang("Some Amazing Features")?></h3>
                <ul class="featuresList pull-left col-lg-12">
                    <li class="col-lg-3 col-md-6 col-sm-6 col-xs-12 wow fadeInLeft" data-wow-delay="0.3s">
                        <div class="feature-item text-center clearfix hvr-pop">
                            <div class="circle bigCircle center-block">
                                <span><i class="fa fa-laptop customColor"></i></span>
                            </div>
                            <span class="feature-item_title text-uppercase text-center ralewaySemiBold col-lg-12 col-md-12 col-sm-12 col-xs-12 blackTxtColor"> <?=_lang("RESPONSIVE DESIGN")?> </span>
                            <span class="feature-item_desc text-center raleway col-lg-12 col-md-12 col-sm-12 col-xs-12"> <?=_lang("Super flexible Web Dashboard resizable according to the size of your device for a perfect accessiblity")?> </span>
                        </div>
                    </li>
                    <li class="col-lg-3 col-md-6 col-sm-6 col-xs-12 wow fadeInUp" data-wow-delay="0.3s">
                        <div class="feature-item text-center clearfix hvr-pop">
                            <div class="circle bigCircle center-block">
                                <span><i class="fa fa-flask customColor"></i></span>
                            </div>
                            <span class="feature-item_title text-uppercase text-center ralewaySemiBold col-lg-12 col-md-12 col-sm-12 col-xs-12 blackTxtColor"> <?=_lang("EASY TO CUSTOMIZE")?>  </span>
                            <span class="feature-item_desc text-center raleway col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <?=_lang("No coding knowledge required! Design, manage and customize everything from your dashboard")?>. </span>
                        </div>
                    </li>
                    <li class="col-lg-3 col-md-6 col-sm-6 col-xs-12 wow fadeInUp" data-wow-delay="0.3s">
                        <div class="feature-item text-center clearfix hvr-pop">
                            <div class="circle bigCircle center-block">
                                <span><i class="fa fa-plane customColor"></i></span>
                            </div>
                            <span class="feature-item_title text-uppercase text-center ralewaySemiBold col-lg-12 col-md-12 col-sm-12 col-xs-12 blackTxtColor"> <?=_lang("PERFECT SHOWCASE")?>  </span>
                            <span class="feature-item_desc text-center raleway col-lg-12 col-md-12 col-sm-12 col-xs-12"><?=_lang("User friendly interface. Runs smoothly and efficiently across all mobile platforms.")?></span>
                        </div>
                    </li>
                    <li class="col-lg-3 col-md-6 col-sm-6 col-xs-12 wow fadeInRight" data-wow-delay="0.3s">
                        <div class="feature-item text-center clearfix hvr-pop">
                            <div class="circle bigCircle center-block">
                                <span><i class="fa fa-cog customColor"></i></span>
                            </div>
                            <span class="feature-item_title text-uppercase text-center ralewaySemiBold col-lg-12 col-md-12 col-sm-12 col-xs-12 blackTxtColor"><?=_lang("Structured code")?> </span>
                            <span class="feature-item_desc text-center raleway col-lg-12 col-md-12 col-sm-12 col-xs-12"><?=_lang("Modular app architecture allows to understand the code logic for future improvements")?></span>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="skew_prepended whiteSection"></div>
</section>
		<section id="newFeature" class="pageRow newFeatureBox paralax skew skew-bottom customBgColor trianglifyBox hidden">
			<div class="wrapper">
				<div class="downloadConainer row">
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 clearfix">
						<a href="app-store.html" class="ellipseBtn smallBtn customWhiteBtn hvr-pop pull-left clear">
							<span class="text-uppercase">new</span>
						</a>
						<h3 class="sectionName ralewaySemiBold pull-left whiteTxtColor clear">Live conference support available</h3>
						<div class="sectionDesc raleway whiteTxtColor pull-left clear">Eleifend morbi orci velit porttitor sed imperdiet ac ullamcorper Fusce eget tortor vel magna iaculis convallis. Aeneaneros vitae metus pellentesque tincidunt.Cum sociis natoque penatibus et magnis dis parturient montes.</div>
						<div class="downloadBox pull-left clear arrowFreeDownload">
							<span class="downloadBox-text ralewayMedium whiteTxtColor pull-left">Free Download On</span>
							<span class="downloadBox-appbox ralewayMediumBold whiteTxtColor pull-left text-center">
								<i class="fa fa-android"></i>
								ANDROID
							</span>
							<span class="downloadBox-appbox ralewayMediumBold whiteTxtColor pull-left text-center">
								<i class="fa fa-apple"></i>
								iOS
							</span>
						</div>
					</div>
					<div class="posterBox col-lg-6 col-md-6 col-sm-6 col-xs-12">
						<img class="wow fadeInRight" src="media/home/2.png" alt="Poster" data-wow-delay="0.3s">
					</div>
				</div>
			</div>
			<div class="skew_appended whiteSection"></div>
		</section>
<section id="choose" class="pageRow">
    <div class="wrapper">
        <div class="chooseApp row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 clearfix">
                <h3 class="sectionTitle text-center ralewayLight balck"><?=_lang("Why Choose Nearbystores")?> </h3>
                <div class="row">
                    <div class="optionsBox col-lg-12 col-md-12 col-sm-12 col-xs-12 clearfix">
                        <div class="centerPhone col-lg-4 col-md-4 col-sm-4 col-xs-12 text-center">
                            <img style="width: 300px" class="wow bounceIn" src="<?=base_url("views/skin/frontend/".FRONTEND_TEMPLATE_NAME."/media/app-screen.jpg")?>" alt="Phone" data-wow-delay="0.3s">
                        </div>
                        <ul class="optionsList pageRow">
                            <li class="pull-left col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                <div class="options-item wow fadeInLeft" data-wow-delay="0.3s">
                                    <div class="circle smallCircle">
                                        <span><i class="fa fa-cubes customColor"></i></span>
                                    </div>
                                    <h4 class="options-name ralewaySemiBold text-uppercase text-right blackTxtColor"><?=_lang("Native Mobile Application")?>   </h4>
                                    <span class="options-desc raleway text-right"><?=_lang("User friendly, available across all mobile platforms (Android & iOS). and can be downloaded from the Google Play store and Apple Store respectively.")?> </span>
                                    <span class="option-dots"></span>
                                </div>
                            </li>
                            <li class="pull-right col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                <div class="options-item wow fadeInRight" data-wow-delay="0.3s">
                                    <div class="circle smallCircle">
                                        <span><i class="fa fa-flag customColor"></i></span>
                                    </div>
                                    <h4 class="options-name ralewaySemiBold text-uppercase text-left blackTxtColor"><?=_lang("Language Translator")?></h4>
                                    <span class="options-desc raleway text-left"><?=_lang("Exceptional language translator option designed to translate any sentence/phrase into the numerous languages available")?>.</span>
                                    <span class="option-dots"></span>
                                </div>
                            </li>
                            <li class="pull-left col-lg-4 col-md-4 col-sm-4 col-xs-12 clear">
                                <div class="options-item wow fadeInLeft" data-wow-delay="0.3s">
                                    <div class="circle smallCircle">
                                        <span><i class="fa fa-desktop customColor"></i></span>
                                    </div>
                                    <h4 class="options-name ralewaySemiBold text-uppercase text-right blackTxtColor"><?=_lang("Powerful control panel")?></h4>
                                    <span class="options-desc raleway text-right"><?=_lang("The dashboard gives you full visibility of the use of the application. graphs and tables are present to give you a better traceability")?> </span>
                                    <span class="option-dots"></span>
                                </div>
                            </li>
                            <li class="pull-right col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                <div class="options-item wow fadeInRight" data-wow-delay="0.3s">
                                    <div class="circle smallCircle">
                                        <span><i class="fa fa-comment customColor"></i></span>
                                    </div>
                                    <h4 class="options-name ralewaySemiBold text-uppercase text-left blackTxtColor"><?=_lang("24/7 Customers-Care services & Unlimited Real Time Chat")?></h4>
                                    <span class="options-desc raleway text-left"><?=_lang("Round the clock interactions between users/customers and business owners/representatives.")?> </span>
                                    <span class="option-dots"></span>
                                </div>
                            </li>
                            <li class="pull-left col-lg-4 col-md-4 col-sm-4 col-xs-12 clear">
                                <div class="options-item wow fadeInLeft" data-wow-delay="0.3s">
                                    <div class="circle smallCircle">
                                        <span><i class="fa fa-money customColor"></i></span>
                                    </div>
                                    <h4 class="options-name ralewaySemiBold text-uppercase text-right blackTxtColor"><?=_lang("Integrated e-payment system")?></h4>
                                    <span class="options-desc raleway text-right"><?=_lang("Secured/integrated mobile payment channel")?>.</span>
                                </div>
                            </li>
                            <li class="pull-right col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                <div class="options-item wow fadeInRight" data-wow-delay="0.3s">
                                    <div class="circle smallCircle">
                                        <span><i class="fa fa-send customColor"></i></span>
                                    </div>
                                    <h4 class="options-name ralewaySemiBold text-uppercase text-left blackTxtColor"><?=_lang("Push Notification")?></h4>
                                    <span class="options-desc raleway text-left"><?=_lang("Alerts your customers/clients about new deals/offers, promotions and campaigns from your store")?>.</span>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
		<section id="reviews" class="pageRow full-width-slider-controls paralax skew skew-top customBgColor trianglifyBox hidden">
			<div class="wrapper">
				<div class="reviewsContainer row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 clearfix staticBox">
						<div class="bottom-bracket whiteTxtColor circleBox center-block text-center"><i class="fa fa-quote-right"></i></div>
						<h3 class="reviews-title whiteTxtColor raleway text-center reviewsArrow">App Reviews</h3>
						<span class="reviews-subtitle raleway whiteTxtColor text-center">Read What Our Happy Customers Are Saying</span>
						<div id="owl-reviews" class="owl-carousel white-control review-full-width staticBox">
							<div class="review-item">
								<div class="review-slide">
									<div class="review-slide_text whiteTxtColor ralewayMedium text-center">Eleifend morbi orci velit porttitor sed imperdiet ac ullamcorper Fusce eget tortor vel magna iaculis convallis. Aeneaneros vitae metus pellentesque tincidunt.Cum sociis natoque penatibus et magnis dis parturient montes turpis donec tincidunt tellus.</div>
									<div class="review-slide_autor center-block">
										<div class="review-slide_autor-ava circleBox wow rotateIn" data-wow-delay="0.3s">
											<img src="media/54x54/1.jpg" alt="User Ava">
										</div>
										<div class="review-slide_autor-name whiteTxtColor ralewayMedium">Oscar Mendis</div>
										<div class="review-slide_autor-post whiteTxtColor raleway">Director: BoxApp Media Inc.</div>
									</div>
								</div>
							</div>
							<div class="review-item">
								<div class="review-slide">
									<div class="review-slide_text whiteTxtColor ralewayMedium text-center">Eleifend morbi orci velit porttitor sed imperdiet ac ullamcorper Fusce eget tortor vel magna iaculis convallis. Aeneaneros vitae metus pellentesque tincidunt.Cum sociis natoque penatibus et magnis dis parturient montes turpis donec tincidunt tellus.</div>
									<div class="review-slide_autor center-block">
										<div class="review-slide_autor-ava circleBox wow rotateIn" data-wow-delay="0.3s">
											<img src="media/54x54/1.jpg" alt="User Ava">
										</div>
										<div class="review-slide_autor-name whiteTxtColor ralewayMedium">Oscar Mendis</div>
										<div class="review-slide_autor-post whiteTxtColor raleway">Director: BoxApp Media Inc.</div>
									</div>
								</div>
							</div>
							<div class="review-item">
								<div class="review-slide">
									<div class="review-slide_text whiteTxtColor ralewayMedium text-center">Eleifend morbi orci velit porttitor sed imperdiet ac ullamcorper Fusce eget tortor vel magna iaculis convallis. Aeneaneros vitae metus pellentesque tincidunt.Cum sociis natoque penatibus et magnis dis parturient montes turpis donec tincidunt tellus.</div>
									<div class="review-slide_autor center-block">
										<div class="review-slide_autor-ava circleBox wow rotateIn" data-wow-delay="0.3s">
											<img src="media/54x54/1.jpg" alt="User Ava">
										</div>
										<div class="review-slide_autor-name whiteTxtColor ralewayMedium">Oscar Mendis</div>
										<div class="review-slide_autor-post whiteTxtColor raleway">Director: BoxApp Media Inc.</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="skew_prepended whiteSection"></div>
		</section>
		<section id="screenshots-title" class="pageRow">
			<div class="wrapper">
				<div class="screenshotsTitBox row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 clearfix">
						<h3 class="sectionTitle text-center ralewayLight balck"><?=_lang("Nearbystores Screenshots")?></h3>
					</div>
				</div>
			</div>
		</section>
		<section id="screenshots" class="pageRow skew skew-screenshots graySection">
			<div class="wrapper">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 clearfix">
						<div id="owl-screenshots" class="owl-carousel phone-slider">
							<div class="wow fadeInLeft" data-wow-delay="0.3s">
								<img class="screenshot-img" src="<?=base_url("views/skin/frontend/".FRONTEND_TEMPLATE_NAME."/media/screenshot-1.png")?>" alt="Screenshot">
							</div>
							<div class="wow fadeInUp" data-wow-delay="0.3s">
								<img class="screenshot-img" src="<?=base_url("views/skin/frontend/".FRONTEND_TEMPLATE_NAME."/media/screenshot-2.png")?>" alt="Screenshot">
							</div>
							<div class="wow fadeInRight" data-wow-delay="0.3s">
								<img class="screenshot-img" src="<?=base_url("views/skin/frontend/".FRONTEND_TEMPLATE_NAME."/media/screenshot-3.png")?>" alt="Screenshot">
							</div>
                            <div class="wow fadeInRight" data-wow-delay="0.3s">
                                <img class="screenshot-img" src="<?=base_url("views/skin/frontend/".FRONTEND_TEMPLATE_NAME."/media/screenshot-4.png")?>" alt="Screenshot">
                            </div>
                            <div class="wow fadeInRight" data-wow-delay="0.3s">
                                <img class="screenshot-img" src="<?=base_url("views/skin/frontend/".FRONTEND_TEMPLATE_NAME."/media/screenshot-5.png")?>" alt="Screenshot">
                            </div>
                            <div class="wow fadeInRight" data-wow-delay="0.3s">
                                <img class="screenshot-img" src="<?=base_url("views/skin/frontend/".FRONTEND_TEMPLATE_NAME."/media/screenshot-6.png")?>" alt="Screenshot">
                            </div>
                            <div class="wow fadeInRight" data-wow-delay="0.3s">
                                <img class="screenshot-img" src="<?=base_url("views/skin/frontend/".FRONTEND_TEMPLATE_NAME."/media/screenshot-7.png")?>" alt="Screenshot">
                            </div>
                            <div class="wow fadeInRight" data-wow-delay="0.3s">
                                <img class="screenshot-img" src="<?=base_url("views/skin/frontend/".FRONTEND_TEMPLATE_NAME."/media/screenshot-8.png")?>" alt="Screenshot">
                            </div>
                            <div class="wow fadeInRight" data-wow-delay="0.3s">
                                <img class="screenshot-img" src="<?=base_url("views/skin/frontend/".FRONTEND_TEMPLATE_NAME."/media/screenshot-9.png")?>" alt="Screenshot">
                            </div>
                            <div class="wow fadeInRight" data-wow-delay="0.3s">
                                <img class="screenshot-img" src="<?=base_url("views/skin/frontend/".FRONTEND_TEMPLATE_NAME."/media/screenshot-10.png")?>" alt="Screenshot">
                            </div>
                            <div class="wow fadeInRight" data-wow-delay="0.3s">
                                <img class="screenshot-img" src="<?=base_url("views/skin/frontend/".FRONTEND_TEMPLATE_NAME."/media/screenshot-11.png")?>" alt="Screenshot">
                            </div>
                            <div class="wow fadeInRight" data-wow-delay="0.3s">
                                <img class="screenshot-img" src="<?=base_url("views/skin/frontend/".FRONTEND_TEMPLATE_NAME."/media/screenshot-12.png")?>" alt="Screenshot">
                            </div>

						</div>
					</div>
				</div>
			</div>
			<div class="skew_prepended reverse whiteSection"></div>
		</section>
<section id="support" class="pageRow skew skew-top">
    <div class="wrapper">
        <div class="supportBox row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 clearfix">
                <h3 class="sectionTitle text-center ralewayLight balck"><?=_lang("App Support")?> </h3>
                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 clearfix">
                    <div class="support-item clearfix wow fadeInLeft" data-wow-delay="0.3s">
                        <div class="circle smallCircle">
                            <span><i class="fa fa-map-marker customColor"></i></span>
                        </div>
                        <h4 class="support-item_name ralewaySemiBold blackTxtColor"><?=_lang("Address")?></h4>
                        <div class="support-item_info raleway">Technopark, Boulevard Dammam Casablanca 20202, Morocco</div>
                    </div>
                    <div class="support-item clearfix wow fadeInLeft" data-wow-delay="0.3s">
                        <div class="circle smallCircle">
                            <span><i class="fa fa-phone customColor"></i></span>
                        </div>
                        <h4 class="support-item_name ralewaySemiBold blackTxtColor"><?=_lang("Free Helpline")?></h4>
                        <div class="support-item_info raleway">
                            (212) 625 718 501<!--<br>
									(002) 600 345 333700-->
                        </div>
                    </div>
                    <div class="support-item clearfix wow fadeInLeft" data-wow-delay="0.3s">
                        <div class="circle smallCircle">
                            <span><i class="fa fa-envelope customColor"></i></span>
                        </div>
                        <h4 class="support-item_name ralewaySemiBold blackTxtColor"><?=_lang("Email")?></h4>
                        <div class="support-item_info raleway">
                            <a href="mailto:droideve.tech@gmail.com">droideve.tech@gmail.com</a>
                            <a href="mailto:support@droideve.com">support@droideve.com</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 clearfix">
                    <div class="support-desc raleway"><?=_lang("We provide fast and reliable support to our customers, whether it’s an inquiry, troubleshooting, customization and special requests. If you need help with installation, just send us a message form this form")?>.</div>
                    <div class="support-formbox clearfix wow fadeInRight" data-wow-delay="0.3s">
                        <div id="success"></div>
                        <form novalidate id="contactForm" class="support-form form-inline" name="sentMessage">
                            <div class="form-group half-wigth pull-left">
                                <label class="sr-only" for="user-name">Full Name</label>
                                <input type="text" data-validation-required-message="Please enter your full name." required class="lineField raleway" id="user-name" placeholder="Full Name *">
                                <p class="help-block text-danger"></p>
                            </div>
                            <div class="form-group half-wigth pull-right">
                                <label class="sr-only" for="user-email">Email</label>
                                <input type="email" data-validation-required-message="Please enter your email address." required class="lineField raleway" id="user-email" placeholder="Email *">
                                <p class="help-block text-danger"></p>
                            </div>
                            <div class="form-group full-width pull-left">
                                <label class="sr-only" for="user-message">Message</label>
                                <textarea data-validation-required-message="Please enter a message." required class="lineField raleway" id="user-message" placeholder="Message"></textarea>
                                <p class="help-block text-danger"></p>
                            </div>
                            <button type="submit" class="ellipseSubmitBtn whiteTxtColor smallBtn ralewayMedium customBgColor hvr-pop pull-left clear"><?=_lang("Send")?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="skew_prepended graySection"></div>
</section>
