<div class="modal fade" id="fmodal-default">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">

                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title"><b><?=_lang("Confirmation!")?></b></h4>
            </div>
            <div class="modal-body">

                <div class="row">
                    <div style="text-align: center">
                        <h3 class="text-red"><?=Translate::sprint("Are you sure?")?></h3>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal"><?=Translate::sprint("Cancel","Cancel")?></button>
                <button type="button" id="apply_confirm" class="btn btn-flat btn-primary"><?=Translate::sprint("Apply")?></button>
            </div>
        </div>

        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<?=TemplateManager::loadHTML()?>

<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        Version <?php if (defined("_APP_VERSION")) echo _APP_VERSION; else echo APP_VERSION; ?>
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; <?= date("Y") ?> <a style="text-transform: uppercase"
                                                 href="<?= site_url("") ?>"><?= APP_NAME ?></a>.</strong> <?= Translate::sprint("All rights reserved.") ?>
    <!--          Template Designed by <a target="_blank" href="https://adminlte.io">Almsaeed Studio</a>-->
</footer>


</div><!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<script src="<?= base_url("views/skin/backend/plugins/jQuery/jquery-2.2.3.min.js") ?>"></script>
<script src="<?= base_url("views/skin/backend/bootstrap/js/bootstrap.min.js") ?>"></script>
<script src="<?= base_url("views/skin/backend/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js") ?>"></script>
<!-- AdminLTE App -->
<script src="<?= base_url("views/skin/backend/dist/js/app.js") ?>"></script>

<script>

    //Colorpicker
    var html_editable = "<div class='pull-right'><button class='hidden' id='enable_html'><?=Translate::sprint("Enable HTML editor")?></button></div>";

    var html_enabled = false;

    $("#editable-textarea").after(html_editable);

    /*if($("#editable-textarea").val() !== ""){
        $('#enable_html').removeClass('hidden');
    }

    $("#editable-textarea").focusout(function () {
        var text = $(this).val();
        if(text !== ""){
            $('#enable_html').removeClass('hidden');
        }else {
            $('#enable_html').addClass('hidden');
        }
    });

    $("#editable-textarea").keyup(function () {
        var text = $(this).val();
        if(text !== ""){
            $('#enable_html').removeClass('hidden');
        }else {
            $('#enable_html').addClass('hidden');
        }
    });*/

    $("#editable-textarea").wysihtml5({
        "image": false,
        "link": false,
        "font-styles": true, //Font styling, e.g. h1, h2, etc. Default true
        "emphasis": true, //Italics, bold, etc. Default true
        "lists": true, //(Un)ordered lists, e.g. Bullets, Numbers. Default true
        "html": false, //Button which allows you to edit the generated HTML. Default false
        "color": false //Button to change color of font
    });

    $("#enable_html").on('click',function () {

        $(this).addClass('hidden');
        $(this).addClass('hidden');

        if(!html_enabled){

            let ed = $("#editable-textarea");

            var text = ed.val();
            text = text.replace(/(?:\r\n|\r|\n)/g, '<br>');

            ed.val(text);

            ed.wysihtml5({
                "image": false,
                "link": false,
                "font-styles": true, //Font styling, e.g. h1, h2, etc. Default true
                "emphasis": true, //Italics, bold, etc. Default true
                "lists": true, //(Un)ordered lists, e.g. Bullets, Numbers. Default true
                "html": false, //Button which allows you to edit the generated HTML. Default false
                "color": false //Button to change color of font
            });
        }


        html_enabled = true;

        return false;
    });

    /**/
</script>

<script>

    var NSTemplateUIAnimation = {

        button: {

            set loading(selector){
                var text  = selector.text().trim();
                selector.attr("disabled",true);
                selector.html("<i class=\"fa fa-spinner fa-spin\" aria-hidden=\"true\"></i>&nbsp;&nbsp;"+text);
            },

            set success(selector) {
                var text  = selector.text().trim();
                selector.html(text);
                selector.html("<i class=\"btn-saving-cart fa fa-check\" aria-hidden=\"true\"></i>&nbsp;&nbsp;"+text);
                selector.addClass('bg-green');
                selector.attr("disabled",true);
            },
            set default(selector) {
                var text  = selector.text().trim();
                selector.html(text);
                selector.attr("disabled",false);
            },

            // selector.html('<i class="btn-saving-cart fa fa-check" aria-hidden="true"></i>&nbsp;&nbsp;<?=Translate::sprint("Mail Sent")?>&nbsp;&nbsp;');
        },

        buttonWithIcon: {

            set loading(selector){
                var text  = selector.html().trim();
                selector.html("<i class=\"fa fa-spinner fa-spin\" aria-hidden=\"true\"></i>&nbsp;&nbsp;"+text);
            },

            set success(selector) {
                var text  = selector.html().trim();
                selector.html(text);
            },
            set default(selector) {
                var text  = selector.html().trim();
                selector.html(text);
            },

        },


    };

</script>


<script>

    <?php
    $link = $this->session->userdata("redirect_to");
    if($link!=""){
        echo "redirect('".$link."')";
        $this->session->set_userdata(array(
            "redirect_to" => ""
        ));
    }

    ?>


    function redirect(url) {
        document.location.href=url;
        //window.open(url, '_target');
        setTimeout(function () {

        },2000);
    }

</script>


<?php
echo TemplateManager::loadScripts();
?>



<script>

    $("#menu-search").removeClass('hidden');

    var last_active_selector = null;

    $( ".sidebar-menu li").each(function( index ) {

        if(!$(this).hasClass('header')){
            var text = $(this).children("a").text();
            text = text.trim().replace(/(<([^>]+)>)/ig,"");
            $(this).attr('data-search',text);
            $(this).attr('data-search-key',text.replace(/ /g,"_"));
            $(this).addClass('parent');
            //$(this).children('ul').attr('data-search-child',text);
            //set text for parents
            if($(this).hasClass('treeview')){
                $(this).find('ul.treeview-menu > li').attr('data-search-parent',text);
                $(this).find('ul.treeview-menu > li').attr('data-search-parent-key',text.replace(/ /g,"_"));
                $(this).find('ul.treeview-menu > li').removeClass('parent');
            }

            if($(this).hasClass('active')){
                last_active_selector = $(this);
            }
        }

    });

    $("#menu-search input[type=text]").keyup(function () {

        var collected_data = {};

        var text = $(this).val();
        if(text !== ""){

            $('.sidebar-menu li').addClass('hidden');
            $('.sidebar-menu li#menu-search').removeClass('hidden');
            $('.sidebar-menu li#reset-search').remove();
            $('#menu-search').after('<li id="reset-search"><a href="#"><i class="mdi mdi-arrow-left"></i>&nbsp;&nbsp;<?=_lang('Back')?></a></li>');

            searchInMenu($(this),text);

        }else {

            $('.sidebar-menu li').removeClass('hidden');
            $('.sidebar-menu li').removeClass('active');
            $('.sidebar-menu li#reset-search').remove();

            if(last_active_selector !== null){
                last_active_selector.addClass('active');
                var attr_key = last_active_selector.attr('data-search-parent-key');
                $('li[data-search-key='+attr_key+']').addClass('active');
            }
        }

        $('.sidebar-menu li#reset-search').on('click',function () {
            $("#menu-search input[type=text]").val('');
            $('.sidebar-menu li').removeClass('hidden');
            $('.sidebar-menu li').removeClass('active');
            $('.sidebar-menu li#reset-search').remove();

            if(last_active_selector !== null){
                last_active_selector.addClass('active');
                var attr_key = last_active_selector.attr('data-search-parent-key');
                $('li[data-search-key='+attr_key+']').addClass('active');
            }

            return false;
        });


    });

    function searchInMenu(selector,query) {

        $( ".sidebar-menu li[data-search]").each(function( index ) {

            var data_search_value = $(this).attr('data-search');
            data_search_value = data_search_value.toLowerCase();
            query = query.toLowerCase();

            var n = data_search_value.search(query);
            if(n>=0){

                var attr_parent_key = $(this).attr('data-search-parent-key');

                $(this).removeClass('hidden');
                $('li[data-search-key='+attr_parent_key+']').removeClass('hidden').addClass('active');
                if($(this).hasClass('treeview')){
                    $(this).addClass('active');
                    $(this).find('ul.treeview-menu > li').removeClass('active');
                    $(this).find('ul.treeview-menu > li').removeClass('hidden');
                }
            }

        });

    }


</script>


<script>


    $('a.linkAccess').on('click', function () {
        var url = ($(this).attr('href'));
        executeURL(url);
    });


    function executeURL(url) {

        $.ajax({
            type: 'get',
            url: url,
            dataType: 'json',
            beforeSend: function (xhr) {
                $(".linkAccess").attr("disabled", true);
            }, error: function (request, status, error) {
                NSAlertManager.simple_alert.request = "<?=Translate::sprint("Input invalid")?>";
                $(".linkAccess").attr("disabled", false);
            },
            success: function (data, textStatus, jqXHR) {

                $('#modal-default').modal('hide');
                $(".linkAccess").attr("disabled", false);
                if (data.success === 1) {
                    document.location.reload();
                } else if (data.success === 0) {
                    var errorMsg = "";
                    for (var key in data.errors) {
                        errorMsg = errorMsg + data.errors[key] + "<br/>";
                    }
                    if (errorMsg !== "") {
                        NSAlertManager.simple_alert.request = errorMsg;
                    }
                }
            }

        });

        return false;
    }

</script>

</body>
</html>