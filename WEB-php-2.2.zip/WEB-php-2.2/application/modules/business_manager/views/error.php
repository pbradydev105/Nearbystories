


<div id="app" class="framework7-root">
    <div id="erros-form" class="page-content no-padding-top" data-item="">
        <!--<a href="#" class="link back close-button">
            <i class="mdi mdi-close"></i>
        </a>-->
        <div class="block">
            <div class="form-container">

                <div class="list no-hairlines custom-form">

                    <h1 class="create-title"><?=_lang("Error 404")?></h1>

                    <div class="row">
                        <div class="col-100">
                            <a href="<?=business_manager_url("index?lang=".Translate::getDefaultLangCode()."&uri=businesses")?>" class="big-button button clickable link" > <i
                                    class="mdi mdi-home"></i>&nbsp;<?= _lang("go Home") ?></a>
                        </div>
                    </div>



                </div>

            </div>
        </div>
    </div>
</div>



