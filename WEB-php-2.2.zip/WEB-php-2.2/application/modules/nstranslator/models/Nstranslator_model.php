<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Nstranslator_model extends CI_Model {




    
  
}

