<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Stripe_api extends MAIN_Controller {

    public $_api_context;

    function  __construct()
    {
        parent::__construct();
        $this->load->config('payment/stripe-config');


    }


    public function create_payment_with_stripe(){


        if(!SessionManager::isLogged()){
            echo "Login is required";
            return;
        }

        $stripeToken = $this->input->post('stripeToken');
        $user_email = SessionManager::getData("email");
        $item_data = $this->session->payment_stripe_cart;
        $items = $item_data["items"];


        try {

            $this->load->library("payment/stripeapi");

            \Stripe\Stripe::setApiKey($this->config->item('stripe_secret_key'));

            $customer = \Stripe\Customer::create(array(
                'email' => $user_email,
                'description' => 'Payment date: '.date("Y-m-d H:i:s",time()),
                'source'   => $stripeToken
            ));

            $amount = ceil($item_data['details_subtotal']*100);

            $result = \Stripe\Charge::create(array(
                'customer' => $customer->id,
                'amount'   => $amount,
                'currency' => $item_data['items'][0]['currency']
            ));

            if($result->paid == 1){

                $transaction_id = $result->id;
                $callback = $item_data['callback_success_url']."&method=stripe&paymentId=".$transaction_id."&PayerID=".$customer->id;
                redirect($callback);

            }


        } catch (Exception $e) {
            echo "<h3>Error</h3>";
            print_r($e->getMessage());
        }

    }


    /*

	public function process(){

		if(ajax_page()){
			$token  = post('stripeToken');
			$ids  = post('ids');
			$plan  = post('plan');
			$payment_method = post('payment_method');
			$package = $this->model->get("*", $this->tb_packages, "ids = '".$ids."'  AND status = 1");
			$user = $this->model->get("*", $this->tb_users, "id = '".session("uid")."'");

			if(!empty($package) && !empty($user)){

                $this->load->library('stripeapi');

				$price_monthly = $package->price_monthly;
		        $price_annually = $package->price_annually;


				$amount = $price_monthly;
				if($plan == 2){
					$amount = $price_annually*12;
				}else{
					$plan = 1;
				}

				try {

					\Stripe\Stripe::setApiKey(get_option('stripe_secret_key'));

					$customer = \Stripe\Customer::create(array(
						'email' => $user->email,
						'description' => 'Payment date: '.date("Y-m-d H:i:s",time()),
				  		'source'   => $token
					));

					$ids = ids();

					if($payment_method == 1){

						$result = \Stripe\Plan::create(array(
						    "amount" => $amount*100,
						    "interval" => ($plan == 2)?"year":"month",
						    "name" => $package->name,
						    "currency" => get_option('payment_currency','USD'),
						    "id" => $ids
						));

						// Subscribe the customer to the plan
						$result = \Stripe\Subscription::create(array(
						    "customer" => $customer->id,
						    "plan" => $ids
						));

						if($result->status == 'active'){

							//Delete Old Webhook
				        	$subscriptions = $this->model->fetch("billing_agreement_id", "general_payment_subscriptions", "type = 'stripe' AND uid = '".session("uid")."' ");
				        	if(!empty($subscriptions)){
				        		foreach ($subscriptions as $key => $subscription) {
									$sub = \Stripe\Subscription::retrieve( $subscription->billing_agreement_id );
									$sub->cancel();
				        			$this->db->delete("general_payment_subscriptions", array( "billing_agreement_id" => $subscription->billing_agreement_id));
				        		}
				        	}
				        	//End Delete Webhook

							$subscription = array(
								'ids' => ids(),
								'uid' => session("uid"),
								'package' => $package->id,
								'type' => 'stripe',
								'billing_agreement_id' => $result->id,
								'plan' => $plan,
								'status' => 1,
								'created' => NOW
							);

							$this->db->insert('general_payment_subscriptions', $subscription);
						}
					}else{
						$result = \Stripe\Charge::create(array(
							'customer' => $customer->id,
						  	'amount'   => $amount*100,
						  	'currency' => get_option('payment_currency','USD')
						));

						if($result->paid == 1){
							$data = array(
								'ids' => ids(),
								'uid' => session("uid"),
								'package' => $package->id,
								'type' => 'stripe_charge',
								'transaction_id' => $result->id,
								'amount' => $result->amount/100,
								'plan' => $plan,
								'status' => 1,
								'created' => NOW
							);
						}
						$this->db->insert($this->tb_payment_history, $data);
						$this->update_package($package, $plan);
					}

					redirect(cn('thank_you'));
				} catch (Exception $e) {
					redirect(cn('pricing'));
				}
			}else{
				redirect(cn('pricing'));
			}
		}
	}

    */
	public function webhook(){
		$this->load->library('stripeapi');
		\Stripe\Stripe::setApiKey(get_option('stripe_secret_key'));

		$payload = @file_get_contents('php://input');
		$event = null;

		$data = json_decode($payload);

		if(is_object($data)){
			try {
			    $event = \Stripe\Event::retrieve($data->id);
			} catch(\UnexpectedValueException $e) {
			    // Invalid payload
			    http_response_code(400);
			    exit();
			}

			// Handle the event
			switch ($event->type) {
			    case 'payment_intent.succeeded':
			        $result = $event->data->object; // contains a \Stripe\PaymentIntent

					$customer = $result->customer;
					$subscription = $this->model->get("*", "general_payment_subscriptions", "", "id", "DESC");

					$id = $subscription->package;
					$plan = $subscription->plan;
					$paymentId = $result->id;

					$package = $this->model->get("*", $this->tb_packages, "id= '".$id."'  AND status = 1");
					if(!empty($package)){
						$data = array(
							'ids' => ids(),
							'uid' => $subscription->uid,
							'package' => $package->id,
							'type' => 'stripe_charge',
							'transaction_id' => $paymentId,
							'amount' => $result->amount/100,
							'plan' => $plan,
							'status' => 1,
							'created' => NOW
						);
						$this->db->insert($this->tb_payment_history, $data);
						$this->update_package($package, $plan, $subscription->uid);

						echo "true";
					}else{
						echo "false";
					}
			        break;
			    case 'payment_method.attached':
			        break;
			    default:
			        http_response_code(400);
			        exit();
			}

			http_response_code(200);
		}
	}

}