<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Created by Console.
 * User: Droideve Technology
 * Date: {date}
 * Time: {time}
 */

class Setting_model extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }


}