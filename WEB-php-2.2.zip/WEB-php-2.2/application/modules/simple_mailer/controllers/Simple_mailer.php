<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Created by Console.
 * User: Amine Maagoul
 * Date: {date}
 * Time: {time}
 */

class Simple_mailer extends MAIN_Controller {

	private $module = "simple_mailer";

	public function __construct(){
        parent::__construct();
        $this->init($this->module);
    }


    public function onLoad()
    {
        $this->load->helper("simple_mailer/email");
        $this->load->model("simple_mailer/Mailer_model","mMailer");
    }

    public function onCommitted($isEnabled)
    {

    	if(!$isEnabled)
    		return;

    }

    /*
     * $data => default_from, default_to, template,
     */

    public function mailer_editor($data){

        $wysihtml5Lib = base_url("views/skin/backend/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js");

		TemplateManager::addScriptLibs($wysihtml5Lib);
		TemplateManager::addScript(
			$this->load->view('simple_mailer/scripts/global_js',NULL,TRUE)
		);

        $this->load->view("backend/header",$data);
        $this->load->view("simple_mailer/backend/send-mail");
        $this->load->view("backend/footer");

    }

    public function onInstall()
    {

        return TRUE;
    }

    public function onEnable()
    {
        return TRUE;
    }

    public function onDisable()
    {
        return TRUE;
    }

    public function onUpgrade()
    {
        return TRUE;
    }


}



/* End of file ArticleDB.php */
