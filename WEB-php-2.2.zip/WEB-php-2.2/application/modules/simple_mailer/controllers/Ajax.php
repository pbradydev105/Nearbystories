<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Created by Console.
 * User: Amine Maagoul
 * Date: {date}
 * Time: {time}
 */

class Ajax extends AJAX_Controller  {

	private $module = "mailer";


	public function __construct()
    {
        parent::__construct();
    }


    public function send(){

		//send mail here
		$from_email = $this->input->post("from-email");
		$to_email = $this->input->post("to-email");

		$to_cc = $this->input->post("to-cc");
		$to_bcc = $this->input->post("to-bcc");
		$subject = $this->input->post("subject");
		$content = $this->input->post("content");
		$attachments = $this->input->post("attachments");



		$result = $this->mMailer->send(array(
			"from_email" 	=> $from_email,
			"to_email" 		=> $to_email,
			"to_cc" 		=> $to_cc,
			"to_bcc" 		=> $to_bcc,
			"subject" 		=> $subject,
			"content" 		=> $content,
			"attachments" 	=> $attachments,
		));


        echo json_encode($result);
        return;

    }



}
