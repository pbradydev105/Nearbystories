<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Created by Console.
 * User: Amine Maagoul
 * Date: {date}
 * Time: {time}
 */

class Admin extends ADMIN_Controller {

	private $module = "mailer";

    public function __construct(){
        parent::__construct();

        //$this->load->model("MailerModel","mMailer");

    }

    /*
     * $data => default_from, default_to, template,
     */

    public function mailer_editor($data){


		$wysihtml5Lib = TEMPLATE_SKIN_URL."/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js";

		TemplateManager::addScriptLibs($wysihtml5Lib);
		TemplateManager::addScript(
			$this->load->view('simple_mailer/scripts/global_js',NULL,TRUE)
		);

        $this->template->header();
        $this->template->sidebar();
        $this->template->sendmail($data);
        $this->template->footer();

    }





}



/* End of file ArticleDB.php */
