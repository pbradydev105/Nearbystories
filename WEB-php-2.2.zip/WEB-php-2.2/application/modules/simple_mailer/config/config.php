<?php
/**
 * Created by Console.
 * User: {user}
 * Date: {date}
 * Time: {time}
 */


/*
|--------------------------------------------------------------------------
| CUSTOM SMTP
|--------------------------------------------------------------------------
|
|
*/

$config = array(
	'email_smtp_enabled' => FALSE
);
