<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Created by Console.
 * User: Amine Maagoul
 * Date: {date}
 * Time: {time}
 */

class Mailer_model extends CI_Model
{


    public function __construct()
    {
        parent::__construct();

    }


    public function send($params=array()){

		extract($params);

		$errors = array();
    	$data = array();

    	if(isset($from_email) AND $from_email!=""
			AND Text::checkEmailFields($from_email))
    		$data["from_email"] = $from_email;
    	else
    		$errors[] = Translate::sprint("Your email is not valid!");


    	//recipients
    	if(isset($to_email) and !empty($to_email)){

    		foreach ($to_email as $value) {

				if (Text::checkEmailFields($value)){

					$data["recipients"][] = $value;

				}
				/*else if(is_numeric($value) and intval($value)>0){

					if($this->mUser->isLogged()){

						$contact_id = intval(intval($value));

						$user = $this->user->getUser();
						$contact = ContactDB::where("id",$contact_id)
							->where("app_id",$user->app_id)->first();

						if($contact!=NULL){
							$data["recipients"][] = $contact->email;
						}

					}


				}*/
			}

		}else{
			$errors[] = Translate::sprint("Recipient email field is empty!");
		}

		//cc recipients
		if(isset($to_cc) and !empty($to_cc)){

			foreach ($to_cc as $value) {

				if (Text::checkEmailFields($value)){

					$data["cc_recipients"][] = $value;

				}/*else if(is_numeric($value) and intval($value)>0){

					if($this->mUser->isLogged()){

						$contact_id = intval(intval($value));

						$user = $this->user->getUser();
						$contact = ContactDB::where("id",$contact_id)
							->where("app_id",$user->app_id)->first();

						if($contact!=NULL){
							$data["cc_recipients"][] = $contact->email;
						}

					}


				}*/
			}

		}


		//bcc recipients
		if(isset($to_bcc) and !empty($to_bcc)){

			foreach ($to_bcc as $value) {

				if (Text::checkEmailFields($value)){

					$data["bcc_recipients"][] = $value;

				}/*else if(is_numeric($value) and intval($value)>0){

					if($this->mUser->isLogged()){

						$contact_id = intval(intval($value));

						$user = $this->user->getUser();
						$contact = ContactDB::where("id",$contact_id)
							->where("app_id",$user->app_id)->first();

						if($contact!=NULL){
							$data["bcc_recipients"][] = $contact->email;
						}

					}


				}*/
			}

		}


		if(isset($subject) and $subject!=""){
    		$data["subject"] = trim($subject);
		}else{
			$errors[] = Translate::sprint("Subject field is not valid!");
		}


		if(isset($content) and $content!=""){
			$data["content"] = trim($content);
		}else{
			$errors[] = Translate::sprint("Content field is not valid!");
		}


    	if(empty($errors)){

			$mail = new DTMailer();
			$mail->setRecipient($data["recipients"]);

			if(isset($data["cc_recipients"])
				AND !empty($data["cc_recipients"]))
				$mail->setCc($data["cc_recipients"]);

			if(isset($data["bcc_recipients"])
				AND !empty($data["bcc_recipients"]))
					$mail->setBcc($data["bcc_recipients"]);


			$mail->setFrom($data["from_email"]);
			$mail->setFrom_name($from_name);

			$mail->setMessage($data["content"]);

            $mail->setReplay_to($data["from_email"]);
			$mail->setReplay_to_name($from_name);

			$mail->setType("html");
			$mail->setSubject($data["subject"]);


			if(isset($attachments) and !empty($attachments) and count($attachments)>0){
				$mail->setAttachments($attachments);
			}


			$mail->send();



			return array(Tags::SUCCESS=>1);
		}


		return array(Tags::SUCCESS=>0,Tags::ERRORS=>$errors);

	}


}
