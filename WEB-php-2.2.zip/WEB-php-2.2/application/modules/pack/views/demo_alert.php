<div class="callout callout-warning">
    <p><?php echo Translate::sprint("This module is not integrated with Dealify, you must purchase it separately"); ?> <a class="pull-right" href="#">Buy Now</a></p>
</div>
