<div id="welcome" class="step">

    <h1 class="title">NearbyStores PHP - <?=(FIRST_PLATFORM=="ns-android")?"Android ":"iOS" ?> v<?=APP_VERSION?> - Installation</h1>
    <p>

    </p>

</div>
