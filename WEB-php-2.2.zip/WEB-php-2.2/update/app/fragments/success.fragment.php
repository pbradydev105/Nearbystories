        <div id="success" class="step">
            <span class="icon mdi mdi-check-circle color-green"></span>
            <h2 class="title">Success!</h2>
            <p>Application has been updated successfully!</p>
            
            <div class="sub">Don't forget to remove update directory!</div>

            <div class="go">
                <a  href="<?=APPURL."/myPortal"?>" class="oval button">Go to the dashboard</a>
            </div>
        </div>